# Attention Prediction Paper — Overleaf Upload Guide

## Quick Start (Overleaf)
1. Create a **new blank Overleaf project**
2. Upload ALL files from this ZIP (keep folder structure intact):
   - `main.tex`                ← use this on Overleaf (IEEEtran format)
   - `figs/` folder            ← all 10 figures  
3. Click **Compile** — full 6-page IEEE PDF appears instantly
4. Edit author name/affiliation in lines 12–22 of main.tex

## Local Compile (no Overleaf)
Use `main_local_compile.tex` with pdflatex (article class, no IEEEtran needed):
```
pdflatex main_local_compile.tex
pdflatex main_local_compile.tex   # run twice for TOC/refs
```

## Paper Structure (6 pages, 18 references)
| Section | Content |
|---|---|
| Abstract | Full summary with exact results |
| I. Introduction | Motivation, pandemic context, 5 contributions |
| II. Theoretical Background | Posner attention model, SDT, EDM framework |
| III. Related Work | LA, attention detection, ML in education |
| IV. Dataset | OULAD description, dual-threshold labelling (Eq. 1) |
| V. Methodology | Architecture, 10 features, 4 model equations |
| VI. Results | 10 figures, 3 tables, exact accuracy values |
| VII. Discussion | Non-linearity, SDT validation, ethics, limitations |
| VIII. Conclusion | Summary + future directions |

## Exact Experimental Results (from your notebook)
| Model | Accuracy |
|---|---|
| Logistic Regression | 0.8272180635660817 |
| Random Forest | 0.8571603877776415 |
| XGBoost | 0.8575285311081114 |
| Final Ensemble | 0.8569149588906614 |

## 10 Figures
| File | Caption |
|---|---|
| fig1_architecture.png | System pipeline diagram |
| fig2_accuracy.png | Model accuracy (exact values) |
| fig3_metrics.png | Acc/Prec/Recall/F1/AUC grouped bars |
| fig4_feature_importance.png | XGBoost gain rankings |
| fig5_distribution.png | Class distribution bar+pie |
| fig6_heatmap.png | Pearson correlation heatmap |
| fig7_roc.png | ROC curves all 4 models |
| fig8_confusion_matrices.png | 2x2 confusion matrix grid |
| fig9_engagement_trend.png | VLE activity over time |
| fig10_ensemble.png | Ensemble voting diagram |

## Customisation Checklist
- [ ] Replace author names (line 12)
- [ ] Replace university name and email (lines 14-19)
- [ ] Add acknowledgements section before References if required
- [ ] Check target conference page limit (paper is 6 pages in IEEEtran)
